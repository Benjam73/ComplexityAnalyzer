/**
 * A class to perform your own tests
 */
public class Executable {
    
    public static void main(String[] args) {
        //I can test my class here: create instances and call the method(s), check the results
        //TODO
        Tools to = new Tools();
        int[] tab ={1,8,3,5,0};
        System.out.println(to.sortBubble(tab));

    }
}