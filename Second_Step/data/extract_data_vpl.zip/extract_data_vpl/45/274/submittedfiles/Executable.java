/**
 * A class to perform your own tests
 */
public class Executable {
    
    public static void main(String[] args) {
        //I can test my class here: create instances and call the method(s), check the results
        //TODO
        int[]tab=new int[6];
		tab[0]=2;
		tab[1]=3;
		tab[2]=1;
		tab[3]=1;
		tab[4]=4;
		tab[5]=2;
		sortBubble(int[] tab);

    }
}