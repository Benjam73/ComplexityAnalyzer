/**
 * A class to perform your own tests
 */
public class Executable {
    
    public static void main(String[] args) {
        //I can test my class here: create instances and call the method(s), check the results
        //TODO
        int [] tableau = new int [5];
        tableau[0]=5;
        tableau[1]=2;
        tableau[2]=4;
        tableau[3]=3;
        tableau[4]=1;
        

    }
}