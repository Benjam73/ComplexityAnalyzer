/**
 * A class to perform your own tests
 */
public class Executable {
    
    public static void main(String[] args) {
        //I can test my class here: create instances and call the method(s), check the results
        //TODO
        int[]t=new int[3];
        t[0]=1;
        t[1]=4;
        t[2]=3;
       
        int[]t2=Tools.sortBubble(t);
      
        

    }
}