/**
 * A class to perform your own tests
 * @author hadrien cambazard
 */
public class Executable {
    
    public static void main(String[] args) {
        //I can test my class here: create instances and call the method(s), check the results
        //TODO
        //int[] L = new int[6];
        //for(int k=0;k<L.length;k++){
          //  L[k]=(Math.random()*10)/1;
        //}
        //ReactorPlanner R= new ReactorPlanner(L);
        //for(int k=0;k<L.length;k++){
         //   System.out.print(L[k]+" ");
        //}
        //System.out.println(R.maxProfit());
    }
}